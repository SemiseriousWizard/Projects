#include "mainfirstwindow.h"
#include "ui_mainfirstwindow.h"
#include <QProcess>
#include <QFile>

MainFirstWindow::MainFirstWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainFirstWindow)
{
    ui->setupUi(this);
    secWindow = new MainWindow();
    QFile styleFile(":/style.css");
    styleFile.open( QFile::ReadOnly );
    QString style( styleFile.readAll( ) );
    qApp->setStyleSheet(style);
    styleFile.close();
}

MainFirstWindow::~MainFirstWindow()
{
    delete ui;
}


void MainFirstWindow::on_pushButton_clicked()
{
    secWindow->show();
}

void MainFirstWindow::on_pushButton_2_clicked()
{
    QProcess process(this);
    process.startDetached("C:/Users/user/Documents/QT/TravellingSalesman/run_create_matrix.bat");
}

void MainFirstWindow::on_pushButton_3_clicked()
{
    QProcess process(this);
    process.startDetached("C:/Users/user/Documents/QT/TravellingSalesman/run_solver.bat");
}
