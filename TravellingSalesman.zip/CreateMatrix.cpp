﻿#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main() {
	setlocale(LC_ALL, "");
	cout << "Введите размер матрицы: ";
	int size_matrix = 0;
	cin >> size_matrix;
	fstream file;
	file.open("matrix.txt", ios::out);
	cout << "Введите матрицу смежности:" << endl;
	char* line = new char;
	for (int i = 0; i <= size_matrix; i++) {
		cin.getline(line, 256);
		file << line << endl;
	}
	file.close();
	system("pause");
	return 0;
}