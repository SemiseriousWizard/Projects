﻿#include <iostream>
#include <vector>
#include <string>
#include <iterator>
#include <fstream>
#include <list>
using namespace std;
vector<vector<int>> matrix;
vector<vector<int>> copyMatrix;
vector<vector<int>> grafMatrix;
int M = 9999;
int amount = 6;
vector<pair<int, int>> list_for_paths;
void GetMatrix() {
    matrix.clear();
    fstream mFile;
    mFile.open("C:/Users/user/Documents/QT/TravellingSalesman/matrix.txt", ios::in);
    string s = "";
    list<string> list;
    getline(mFile, s);
    int index = 0;
    string temp_str = "";
    std::vector<int> temp_vector;
    while (!mFile.eof()) {
        s = "";
        getline(mFile, s);
        while (index < s.size()) {
            while (index < s.size() && s[index] != ' ') {
                temp_str += s[index];
                index++;
            }
            list.push_back(temp_str);
            index++;
            temp_str = "";
        }
        while (!list.empty()) {
            temp_vector.push_back(stoi(list.front()));
            list.pop_front();
        }
        if (!temp_vector.empty())
            matrix.push_back(temp_vector);
        temp_vector.clear();
        index = 0;
    }
    mFile.flush();
    mFile.close();
    amount = matrix.size();
}
void InitExtraMatrix() {
    copyMatrix.clear();
    grafMatrix.clear();
    vector<int> temp_vec;
    for (int i = 0; i < amount; i++) {
        for (int j = 0; j < amount; j++)
            if (i == j)
                temp_vec.push_back(-1);
            else
                temp_vec.push_back(matrix[i][j]);
        copyMatrix.push_back(temp_vec);
        temp_vec.clear();
    }
    for (int i = 0; i < amount; i++) {
        for (int j = 0; j < amount; j++)
            temp_vec.push_back(matrix[i][j]);
        grafMatrix.push_back(temp_vec);
        temp_vec.clear();
    }
}
void RowReduction()
{
    int size = amount;
    for (int i = 0; i < size; i++)
    {
        int min = M;
        for (int j = 0; j < size; j++)
        {
            if (copyMatrix[i][j] < min && copyMatrix[i][j] != -1)
                min = copyMatrix[i][j];
        }

        if (min != M && min != 0)
        {
            for (int j = 0; j < size; j++)
            {
                if (copyMatrix[i][j] > 0 && copyMatrix[i][j] != M)
                    copyMatrix[i][j] -= min;
            }
        }
    }
}
void ColumnReduction()
{
    int size = amount;
    for (int i = 0; i < size; i++)
    {
        int min = M;
        for (int j = 0; j < size; j++)
        {
            if (copyMatrix[j][i] < min && copyMatrix[j][i] != -1)
                min = copyMatrix[j][i];
        }

        if (min != M && min != 0)
        {
            for (int j = 0; j < size; j++)
            {
                if (copyMatrix[j][i] > 0 && copyMatrix[j][i] != M)
                    copyMatrix[j][i] -= min;
            }
        }
    }
}
int FindMinInLine(int h, int g)
{
    int min = M;
    for (int i = 0; i < amount; i++)
    {
        if (copyMatrix[h][i] < min && i != g && copyMatrix[h][i] != -1)
            min = copyMatrix[h][i];
    }
    return min;
}
int FindMinInCol(int h, int g)
{
    int min = M;
    for (int i = 0; i < amount; i++)
    {
        if (copyMatrix[i][g] < min && i != h && copyMatrix[i][g] != -1)
            min = copyMatrix[i][g];
    }
    return min;
}
std::pair<int, int> FindPaths()
{
    int max = -M;
    int size = amount;
    vector<vector < int>> cop = copyMatrix;
    std::pair<int, int> way;
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            if (copyMatrix[i][j] == 0)
            {
                int mark = FindMinInLine(i, j) + FindMinInCol(i, j);
                if (max < mark)
                {
                    max = mark;
                    way.first = i;
                    way.second = j;
                }
            }
        }
    }
    //ставим метку на обратный путь, так как назад возвращаться не будем
    if (copyMatrix[way.second][way.first] == 0)
        copyMatrix[way.second][way.first] = -1;

    //удаляем элементы в строке и столбце, так как через этот пункт больше не пойдем
    for (int i = 0; i < size; i++)
    {
        copyMatrix[way.first][i] = -1;
        copyMatrix[i][way.second] = -1;
    }
    return way;
}
void BranchAndBoundMethod()
{
    copyMatrix = grafMatrix;
    for (int i = 0; i < amount; i++)
        for (int j = 0; j < amount; j++)
        {
            if (i == j)
                copyMatrix[i][j] = -1;
            if (copyMatrix[i][j] <= 0)
                copyMatrix[i][j] = -1;
        }

    int ii = 0;
    while (ii != amount)
    {
        RowReduction();
        ColumnReduction();
        std::pair<int, int> tmp;
        tmp = FindPaths();
        if (tmp != std::pair<int, int>(0, 0))
            list_for_paths.push_back(tmp);
        ii++;
    }
}
void print_matrix() {
    cout << "Матрица смежности:" << endl;
    cout << "№\t";
    for (int i = 0; i < matrix.size(); i++)
        cout << i + 1 << "\t";
    cout << endl;
    for (int i = 0; i < matrix.size(); i++) {
        cout << i + 1 << "\t";
        for (int j = 0; j < matrix.size(); j++)
            cout << matrix[i][j] << "\t";
        cout << endl;
    }
    cout << endl;
}

void print_road() {
    cout << "Маршрут:\n";
    int begin = 0;
    for (int i = 0; i < list_for_paths.size(); i++) {
        for (int j = 0; j < list_for_paths.size(); j++) {
            if (list_for_paths[j].first == begin) {
                cout << list_for_paths[j].first + 1;
                cout << " -> ";
                begin = list_for_paths[j].second;
                break;
            }
        }
    }
    bool lastElementPrinted = false;
    for (int j = 0; j < list_for_paths.size(); j++)
        if (list_for_paths[j].first == begin) {
            cout << list_for_paths[j].first + 1;
            lastElementPrinted = true;
            break;
        }
    if (!lastElementPrinted) {
        for (int j = 0; j < list_for_paths.size(); j++)
            if (list_for_paths[j].second == begin)
                cout << list_for_paths[j].second + 1;
    }
    bool hasRoad = false;
    for (int i = 0; i < list_for_paths.size(); i++)
        if (list_for_paths[i].second == 0) {
            hasRoad = true;
            break;
        }
    if (!hasRoad)
        cout << "\nЗадача не имеет решения\n";
    cout << endl;
}

void print_paths() {
    cout << "Отрезки путей:" << endl;
    for (int i = 0; i < list_for_paths.size(); i++)
        cout << list_for_paths[i].first + 1 << " -> " << list_for_paths[i].second + 1 
        << " = " << matrix[list_for_paths[i].first][list_for_paths[i].second] << endl;
}

void sum_paths() {
    int sum = 0;
    cout << "Значение маршрута:\n";
    for (int i = 0; i < list_for_paths.size(); i++)
        sum += matrix[list_for_paths[i].first][list_for_paths[i].second];
    cout << sum << endl;
}

int main()
{
    setlocale(LC_ALL, "");
    GetMatrix();
    InitExtraMatrix();
    print_matrix();
    BranchAndBoundMethod();
    print_paths();
    cout << endl;
    print_road();
    sum_paths();
    system("pause");
    return 0;
}
