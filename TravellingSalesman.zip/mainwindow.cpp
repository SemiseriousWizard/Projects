#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "myglwidget.h"
#include <QPainter>
#include <QGridLayout>
#include <QPushButton>
#include <QFile>
#include <QTextStream>
MainWindow::MainWindow(QWidget *parent)
    :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    myGLWidget *openGLW=new myGLWidget(this);
    QGridLayout *grid=new QGridLayout();
    QPushButton *btn=new QPushButton();
    btn->setText("Построить граф");
    grid->addWidget(openGLW,0,0, 1, 14);
    grid->addWidget(btn,1,6, 1, 2);
    ui->centralwidget->setLayout(grid);
    setWindowTitle("Задача коммивояжёра");
    connect(btn,&QPushButton::clicked,openGLW,&myGLWidget::redraw);
}

MainWindow::~MainWindow()
{
    delete ui;
}
