#ifndef MAINFIRSTWINDOW_H
#define MAINFIRSTWINDOW_H

#include <QMainWindow>
#include "mainwindow.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainFirstWindow; }
QT_END_NAMESPACE

class MainFirstWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainFirstWindow(QWidget *parent = nullptr);
    ~MainFirstWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::MainFirstWindow *ui;
    MainWindow *secWindow;
};
#endif // MAINFIRSTWINDOW_H
